Press A to move left and D to move right, press P to pause and press C to see controls and space to shoot lshift to collect magnets# survive-the-zombie
